function DrawText2D(x,y, width, height, scale, text, r,g,b,a, outline)
	SetTextFont(Config.Text.font)
	SetTextScale(scale, scale)
	SetTextColour(r, g, b, a)
	SetTextDropshadow(0, 0, 0, 0,255)
	SetTextDropShadow()
	if outline then SetTextOutline() end
	BeginTextCommandDisplayText('STRING')
	AddTextComponentSubstringPlayerName(text)
	EndTextCommandDisplayText(x - width/2, y - height/2 + 0.005)
end
function WaitingTime(timee)
	local time = timee
	while time > 0 do
		Wait(0)
		time = time - (GetFrameTime() * 1000)
	end
end