--===============================================
--=== 			CREATED BY SVEJDARPA 		  ===
--===============================================
Config = {}
Config.ESX_enable = true											--allowing/disabling ESX, mainly for notifications
Config.Notifications = true											--allowing/disabling all notification

Config.DisableAutoReload = true											-- this option disable autoreload from the game, you must reload manually, it is more realistic
Config.DisableAutoReloadHP = true										-- this option disable autoreload HP if you been hit, ot if you dead
--===============================================
--=== 			REALISTIC GAS MASK	 		  ===
--===============================================
Config.GasMaskDetect = false										-- in main loop is detecting, if you have a mask and adding you gas protection - less realistic, CMD must be false
Config.GasMaskCMD = false											-- in main loop will be created command for using a gasmask, it was used for testing, better solution is triggerEvent and using item, autodetect MUST be false
Config.CMD = 'gasmask'												-- command for gasmask
Config.RealisticClothing = true										-- better animation for clothing - more realistic
Config.Mask1_Item = 46												-- mask_1 from skin for ITEM
Config.Mask2_Item = 0												-- mask_2 from skin for ITEM
Config.GasMasksWithoutItem = {										-- table of masks for autodetect
	46
}
--------------DISPLAYED TEXT---------------------------
Config.GasMaskOnText = 'You dressed your mask'
Config.GasMaskOffText = 'You undressed your mask'
--------------Usable Client Event----------------------
-- first nil = mask clothes 1
--second nil = mask clothes 2
-- TriggerEvent('gasmask:useItem', nil, nil)
-- TriggerClientEvent('gasmask:useItem', _source, nil, nil)

--===============================================
--=== 		    	Gun Fire Mode 	    	  ===
--===============================================
Config.FireMode = false													--allowing/disabling firemode function
Config.Key = 74 														--switching mode button, default 74 - H
--------------DISPLAYED TEXT---------------------------
Config.TextSafe = 'safe'
Config.TextSingle = 'single'                     
Config.TextBurst = 'burst'
Config.TextAuto = 'auto'
--------------TEXT CONFIGURATION-----------------------
Config.Text2DPosX = 0.815
Config.Text2DPosY = 1.41
Config.Text = {font = 0, scale = 0.335, r = 255, g = 0, b = 0, a = 255} -- if you use SvejdaScriptsFonts you can change the font here(Pangolin, Signika, PermanentMarker)
--------------WEAPON WHICH SHOOTING SINGLE-----------------------
Config.weaponSingle = {
	'WEAPON_PISTOL',
	'WEAPON_COMBATPISTOL',
	'WEAPON_PISTOL_MK2',
	'WEAPON_PISTOL50',
	'WEAPON_SNSPISTOL',
	'WEAPON_SNSPISTOL_MK2',
	'WEAPON_HEAVYPISTOL',
	'WEAPON_VINTAGEPISTOL',
	'WEAPON_MARKSMANPISTOL',
	'WEAPON_REVOLVER',
	'WEAPON_REVOLVER_MK2',
	'WEAPON_DOUBLEACTION',
	'WEAPON_CERAMICPISTOL',
	'WEAPON_NAVYREVOLVER',
	'WEAPON_GADGETPISTOL',
	'WEAPON_SNIPERRIFLE',
	'WEAPON_HEAVYSNIPER',
	'WEAPON_HEAVYSNIPER_MK2',
	'WEAPON_MARKSMANRIFLE',
	'WEAPON_MARKSMANRIFLE_MK2',
	'WEAPON_GRANADELAUNCHER',
	'WEAPON_PUMPSHOTGUN',
	'WEAPON_DBSHOTGUN',
	'WEAPON_PUMPSHOTGUN_MK2',
	'WEAPON_SAWNOFFSHOTGUN',
	'WEAPON_COMBATSHOTGUN'
	
}
--------------WEAPON WHICH SHOOTING SINGLE AND AUTO, WITHOUT SEMI---
Config.weaponAuto = {
	'WEAPON_MICROSMG',
	'WEAPON_SMG',
	'WEAPON_SMG_MK2',
	'WEAPON_ASSAULTSMG',
	'WEAPON_CMBATPDW',
	'WEAPON_MACHINEPISTOL',
	'WEAPON_MINISMG',
	'WEAPON_ASSAULTRIFLE',
	'WEAPON_ASSAULTRIFLE_MK2',
	'WEAPON_COMPACTRIFLE',
	'WEAPON_MILITARYRIFLE',
	'WEAPON_BULLPUPSHOTGUN',
	'WEAPON_HEAVYSHOTGUN',
	'WEAPON_ASSAULTSHOTGUN',
	'WEAPON_AUTOSHOTGUN'
}
-------------WEAPON WHICH SHOOTING SINGLE, SEMI AUTO AND AUTO-------
Config.weaponBurst = {
	'WEAPON_CARBINERIFLE',
	'WEAPON_ADVANCEDRIFLE',
	'WEAPON_CARBINERIFLE_MK2',
	'WEAPON_SPECIALCARBINE',
	'WEAPON_SPECIALCARBINE_MK2',
	'WEAPON_BULLPUPRIFLE',
	'WEAPON_BULLPUPRIFLE_MK2'	
}

function Notification(type, text)
	if Config.ESX_enable then
		if type == 'error' then
			ESX.ShowNotification("~r~"..text, true)
		elseif type == 'success' then
			ESX.ShowNotification("~g~"..text, true)
		elseif type == 'inform' then
			ESX.ShowNotification("~y~"..text, true)
		end
	else
		print("".. text)
	end
end