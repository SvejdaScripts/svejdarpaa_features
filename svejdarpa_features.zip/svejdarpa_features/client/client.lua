Citizen.CreateThread(function()  
	if Config.DisableAutoReload then
		SetWeaponsNoAutoreload(true)
	end
	if Config.DisableAutoReloadHP then
		SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)
	end
	if Config.GasMaskCMD then
		RegisterCommand(""..Config.CMD, function()
			TriggerEvent('gasmask:useItem', nil, nil)
		end)
	end
    while true do       
		if Config.FireMode then
			FireModeFunction()
		end
		if Config.GasMaskDetect then
			GasMaskFunction()
		end



		--WAITING
		if IsPedArmed(PlayerPedId(), 4) then
		else
			Wait(1000)
		end
		Wait(0)
    end
end)