--===============================================
--=== 			 REALISTIC FEATURES	 		  ===
--===============================================
--=== 			CREATED BY SVEJDARPA 		  ===
--===============================================

fx_version 'adamant'

game 'gta5'

description 'in this script you find many usable features for more realistic roleplay, very configurable, SERVER AND CLIENT CONFIG!'

version '1.0'

server_scripts {	
	'@es_extended/locale.lua',
	'@mysql-async/lib/MySQL.lua',
	'server/*.lua',
	'server_config.lua',
}
client_scripts {	
	'@es_extended/locale.lua',	
	'config.lua',
	'functions.lua',
	'client/*.lua',
}

dependencies {
	'es_extended',
}

shared_script '@es_extended/imports.lua'