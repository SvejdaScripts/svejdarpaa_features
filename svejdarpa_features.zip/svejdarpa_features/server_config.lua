--===============================================
--=== 		    	ADD ITEM    	 		  ===
--===============================================
-- not necesary to use this, but you will loose item after use it

RegisterServerEvent('gasmask:addItem')
AddEventHandler('gasmask:addItem', function(item)
    if item == 'mask' then
        print('add gas mask')
    -- Here you can trigger event which you use for adding item back into player inventory  
    end

end)